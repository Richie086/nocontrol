# No Control — self-hosted

    make up          # mirrors 47 tracks (~2.5h of WAV, a few GB), converts to MP3, builds page, runs nginx on :8080

Pieces:
- `tracks.json`   — manifest pulled from the Flow playlist (id, title, duration, source URLs)
- `fetch_audio.sh`— downloads wav/m4a/art from Flow's public storage into `audio/`, makes tagged MP3s
- `build.py`      — renders `index.html`; `--local` points at `audio/`, no flag streams from Flow
- `Dockerfile` + `nginx.conf` + `docker-compose.yml` — static host with range requests + long cache on audio

Put it behind your existing reverse proxy (Caddy/Traefik) for TLS; only port 8080 is exposed.
Re-run `make up` after changing the playlist (re-export tracks.json first).
